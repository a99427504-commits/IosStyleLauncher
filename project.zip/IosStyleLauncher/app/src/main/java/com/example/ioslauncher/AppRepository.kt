package com.example.ioslauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * لیست اپ‌های نصب‌شده فقط یک‌بار در استارت لانچر خوانده می‌شود
 * و در حافظه نگه داشته می‌شود (نه در هر رفرش)، تا فراخوانی سنگین
 * PackageManager تکرار نشود و باتری کمتر مصرف شود.
 */
object AppRepository {

    private var cachedApps: List<AppInfo>? = null

    fun getInstalledApps(context: Context, forceRefresh: Boolean = false): List<AppInfo> {
        if (!forceRefresh && cachedApps != null) return cachedApps!!

        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        val apps = resolveInfos
            .filter { it.activityInfo.packageName != context.packageName }
            .map { info ->
                AppInfo(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.activityInfo.packageName,
                    activityName = info.activityInfo.name
                )
            }
            .distinctBy { it.packageName + it.activityName }
            .sortedBy { it.label.lowercase() }

        cachedApps = apps
        return apps
    }

    fun launchApp(context: Context, app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // اگر اپ حذف شده باشد یا فعالیت در دسترس نباشد، به‌آرامی نادیده گرفته می‌شود
        }
    }
}
