package com.example.ioslauncher

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

/**
 * هر صفحه از هوم‌اسکرین شامل یک RecyclerView با گرید ۵ ستونه است.
 * لیست کامل اپ‌ها به بلوک‌های ۳۵ تایی (۵×۷) تقسیم می‌شود.
 */
class PagerAdapter(
    private val pages: List<List<AppInfo>>,
    private val onAppClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<PagerAdapter.PageViewHolder>() {

    inner class PageViewHolder(val recyclerView: RecyclerView) : RecyclerView.ViewHolder(recyclerView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.page_grid, parent, false) as RecyclerView
        view.layoutParams = ViewPager2.LayoutParams(
            ViewPager2.LayoutParams.MATCH_PARENT,
            ViewPager2.LayoutParams.MATCH_PARENT
        )
        view.layoutManager = GridLayoutManager(parent.context, AppGridAdapter.COLUMNS)
        // چون آیکون‌ها ثابت‌اند و صفحات کم تعداد هستند، setHasFixedSize باعث کاهش محاسبات layout می‌شود
        view.setHasFixedSize(true)
        return PageViewHolder(view)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        holder.recyclerView.adapter = AppGridAdapter(holder.recyclerView.context, pages[position], onAppClick)
    }

    override fun getItemCount(): Int = pages.size
}
