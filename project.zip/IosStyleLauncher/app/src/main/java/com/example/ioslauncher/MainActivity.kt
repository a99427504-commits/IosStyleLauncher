package com.example.ioslauncher

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.ioslauncher.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // نام پکیج اپ‌هایی که در داک (پایین صفحه) ثابت نمایش داده می‌شوند
    // اگر روی گوشی نصب نباشند، به‌سادگی نادیده گرفته می‌شوند
    private val dockPackages = listOf(
        "com.android.dialer",
        "com.android.messaging",
        "com.android.chrome",
        "com.android.camera2"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val allApps = AppRepository.getInstalledApps(this)

        setupPages(allApps)
        setupDock(allApps)
    }

    /** صفحات هوم را می‌سازد: هر صفحه حداکثر ۳۵ اپ (۵×۷) */
    private fun setupPages(allApps: List<AppInfo>) {
        val pages = allApps.chunked(AppGridAdapter.PAGE_SIZE)
            .ifEmpty { listOf(emptyList()) }

        binding.appPager.adapter = PagerAdapter(pages) { app ->
            AppRepository.launchApp(this, app)
        }

        // چون تعداد صفحات کم است، offscreenPageLimit پیش‌فرض کافی است و رم اضافه مصرف نمی‌شود
        setupPageIndicator(pages.size)
        binding.appPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageIndicator(position)
            }
        })
    }

    private fun setupPageIndicator(pageCount: Int) {
        binding.pageIndicator.removeAllViews()
        if (pageCount <= 1) {
            binding.pageIndicator.visibility = View.GONE
            return
        }
        binding.pageIndicator.visibility = View.VISIBLE
        for (i in 0 until pageCount) {
            val dot = ImageView(this)
            val size = (7 * resources.displayMetrics.density).toInt()
            val params = android.widget.LinearLayout.LayoutParams(size, size)
            params.marginStart = (4 * resources.displayMetrics.density).toInt()
            params.marginEnd = (4 * resources.displayMetrics.density).toInt()
            dot.layoutParams = params
            dot.setImageResource(if (i == 0) R.drawable.dot_active else R.drawable.dot_inactive)
            binding.pageIndicator.addView(dot)
        }
    }

    private fun updatePageIndicator(activePosition: Int) {
        for (i in 0 until binding.pageIndicator.childCount) {
            val dot = binding.pageIndicator.getChildAt(i) as ImageView
            dot.setImageResource(if (i == activePosition) R.drawable.dot_active else R.drawable.dot_inactive)
        }
    }

    /** داک پایین صفحه را با اپ‌های موجود در dockPackages پر می‌کند */
    private fun setupDock(allApps: List<AppInfo>) {
        binding.dock.removeAllViews()
        val dockApps = dockPackages.mapNotNull { pkg ->
            allApps.firstOrNull { it.packageName == pkg }
        }

        // اگر هیچ‌کدام از اپ‌های پیش‌فرض پیدا نشد، ۴ اپ اول لیست را به‌عنوان جایگزین می‌گذاریم
        val finalDockApps = dockApps.ifEmpty { allApps.take(4) }

        for (app in finalDockApps) {
            val iconView = layoutInflater.inflate(R.layout.item_dock_app, binding.dock, false) as ImageView
            try {
                iconView.setImageDrawable(packageManager.getApplicationIcon(app.packageName))
            } catch (e: Exception) {
                iconView.setImageDrawable(null)
            }
            iconView.setOnClickListener { AppRepository.launchApp(this, app) }
            binding.dock.addView(iconView)
        }
    }

    /**
     * چون این اکتیویتی نقش لانچر (خانه) را دارد، دکمه Back نباید اپ را ببندد؛
     * این کار رفتار طبیعی لانچرهای اندروید و iOS را شبیه‌سازی می‌کند.
     */
    override fun onBackPressed() {
        // عمداً خالی گذاشته شده — در صفحه اصلی هیچ اقدامی برای دکمه بازگشت وجود ندارد
    }
}
