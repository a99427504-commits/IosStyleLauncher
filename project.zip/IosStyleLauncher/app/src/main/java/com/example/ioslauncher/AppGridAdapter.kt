package com.example.ioslauncher

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * آداپتور یک صفحه گرید (حداکثر ۳۵ آیتم = ۵ ستون × ۷ ردیف).
 * آیکون‌ها به‌صورت lazy لود و کش می‌شوند تا CPU/باتری کمتر مصرف شود.
 */
class AppGridAdapter(
    private val context: Context,
    private val apps: List<AppInfo>,
    private val onAppClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppGridAdapter.AppViewHolder>() {

    companion object {
        const val COLUMNS = 5
        const val ROWS = 7
        const val PAGE_SIZE = COLUMNS * ROWS // 35
    }

    inner class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.label.text = app.label

        // لود تنبل آیکون: فقط وقتی آیتم واقعاً روی صفحه دیده می‌شود
        val cached = app.cachedIcon
        if (cached != null) {
            holder.icon.setImageDrawable(cached)
        } else {
            try {
                val drawable = context.packageManager.getApplicationIcon(app.packageName)
                app.cachedIcon = drawable
                holder.icon.setImageDrawable(drawable)
            } catch (e: Exception) {
                holder.icon.setImageDrawable(null)
            }
        }

        holder.itemView.setOnClickListener { onAppClick(app) }
    }

    override fun getItemCount(): Int = apps.size
}
