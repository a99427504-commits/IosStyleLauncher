package com.example.ioslauncher

import android.graphics.drawable.Drawable

/**
 * مدل ساده اطلاعات یک اپلیکیشن نصب‌شده.
 * عمداً drawable آیکون لود نمی‌شود مگر زمانی که واقعاً روی صفحه دیده شود
 * (lazy loading) تا مصرف رم و باتری کمتر شود.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String
) {
    // کش موقتی آیکون؛ فقط وقتی درخواست شود لود می‌شود
    var cachedIcon: Drawable? = null
}
